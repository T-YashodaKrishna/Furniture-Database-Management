package com.src.services;

import java.sql.SQLException;
import java.util.List;

import com.src.model.AdminLoginModel;
import com.src.model.ButtonModel1;
import com.src.model.CommentsModel;
import com.src.model.CustomerLoginModel;
import com.src.model.FurnitureAddModel;
import com.src.model.RegisterModel;

public interface DbIntr {
public int insertToDb(RegisterModel rm) throws SQLException;
	
	public boolean checkDb(AdminLoginModel lm) throws SQLException;
	
	public boolean checkDb(CustomerLoginModel lm) throws SQLException;
	
	public List<String> getIds() throws SQLException;
	
	public void addCart(ButtonModel1 bm) throws SQLException;
	
	public boolean addComments(CommentsModel cm) throws SQLException;
	
	public int addtofurniture(FurnitureAddModel fam) throws SQLException;
	
	public int deletefromfurniture(String name) throws SQLException;
	
	public int updatefurniture(String name,int price) throws SQLException;
	
}
