package com.src.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.src.model.AdminLoginModel;
import com.src.model.ButtonModel1;
import com.src.model.CommentsModel;
import com.src.model.CustomerLoginModel;
import com.src.model.FurnitureAddModel;
import com.src.model.RegisterModel;

public class DbImpl implements DbIntr {

private static Connection con;
	
	static{
		try {
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:~/test","sa","");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	@Override
	public int insertToDb(RegisterModel rm) throws SQLException {
		PreparedStatement stmt = con.prepareStatement("insert into customer values(?,?,?,?,?)");
		stmt.setString(1, rm.getCid());
		stmt.setString(2, rm.getName());
		stmt.setString(3,rm.getEmail());
		stmt.setString(4,rm.getAddress());
		stmt.setString(5,rm.getPassword());
		return 	stmt.executeUpdate();
	}

	@Override
	public boolean checkDb(AdminLoginModel alm) throws SQLException {
		String query="select m_id from manager where m_id='"+alm.getId()+"' and password='"+alm.getPassword()+"'";
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(query);
		List<String> m_ids=new ArrayList<>();
				while(rs.next()){
			
					m_ids.add(rs.getString(1));
			
		}
				
				if(m_ids.isEmpty()){
				return false;
				}
				else{
					return true;
					
				}
	}

	@Override
	public boolean checkDb(CustomerLoginModel clm) throws SQLException {
		String query="select c_id from customer where c_id='"+clm.getC_id()+"' and password='"+clm.getPassword()+"'";
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(query);
		List<String> c_ids=new ArrayList<>();
				while(rs.next()){
					c_ids.add(rs.getString(1));
			
		}
				
				if(c_ids.isEmpty()){
				return false;
				}
				else{
					return true;
					
				}
	}

	@Override
	public List<String> getIds() throws SQLException {
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select c_id from customer ");
		List<String> c_ids=new ArrayList<>();
		while(rs.next()){
			c_ids.add(rs.getString(1));
		}
		
		return c_ids;
	}

	@Override
	public void addCart(ButtonModel1 bm) throws SQLException {
		// TODO Auto-generated method stub
		String query="insert into cart values('"+bm.getId()+"','"+bm.getItem()+"')";
		Statement stmt=con.createStatement();
	    stmt.executeUpdate(query);
		
	}

	@Override
	public boolean addComments(CommentsModel cm) throws SQLException {
		// TODO Auto-generated method stub
		try{
			String query="insert into review values('"+cm.getC_id()+"','"+cm.getAbout()+"','"+cm.getComments()+"','"+cm.getRating()+"')";
	        Statement stmt= con.createStatement();
	        stmt.executeUpdate(query);
	        return true;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	   
	    
		return false;
	}

	@Override
	public int addtofurniture(FurnitureAddModel fam) throws SQLException {
		// TODO Auto-generated method stub
		PreparedStatement stmt = con.prepareStatement("insert into furniture values(null,?,?,?)");
		
		stmt.setString(1, fam.getName());
		stmt.setInt(2,fam.getPrice());
		stmt.setString(3,fam.getType());
		
		return 	stmt.executeUpdate();
	}

	@Override
	public int deletefromfurniture(String name) throws SQLException {
		PreparedStatement stmt = con.prepareStatement("delete from furniture where f_name='"+name+"'");
		
		return 	stmt.executeUpdate();
	}

	@Override
	public int updatefurniture(String name, int price) throws SQLException {
		PreparedStatement stmt = con.prepareStatement("update furniture set price="+price+" where f_name='"+name+"'");
		return 	stmt.executeUpdate();
	}

}
