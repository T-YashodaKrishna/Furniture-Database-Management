package com.src.model;

public class ButtonModel1 {
	
	private String item;
	
	private String id;
	
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	

}
