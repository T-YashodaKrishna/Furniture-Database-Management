package com.src.validator;

public final class ValidatorClass {
private ValidatorClass(){
		
		
		
	}
	private static final String[] keywords={"drop","delete","insert","update","select","for","while","switch","do"};
	
	public static boolean keywordChecker(String input){
		boolean isInValid=false;
		for(String key:keywords){
			if(key.equalsIgnoreCase(input)){
				isInValid=true;
				break;
			}
			else{
				isInValid=false;
				
			}
	
		}
		return isInValid;	
		
	}
	
	public static boolean charChecker(String input){
		boolean isSpecial=false;
		char[] data=input.toCharArray();
		for(char a:data){
			if(!Character.isLetterOrDigit(a)){
				
				isSpecial=true;
				break;
			}
			else{
				isSpecial=false;
				
				
			}
		}
		return isSpecial;
	}
	
}
