package com.src.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static com.src.validator.ValidatorClass.keywordChecker;
import static com.src.validator.ValidatorClass.charChecker;

import com.src.model.RegisterModel;
import com.src.services.DbIntr;
import com.src.services.FactoryClass;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String c_id=request.getParameter("c_id");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		String password=request.getParameter("password");
		String cpassword=request.getParameter("cpassword");
		HashMap<String,String> errors=new HashMap<>();
		
		ServletContext context = getServletContext();
		List<String> ids=(List<String>)context.getAttribute("ids");
		
		//name
		if(name==null){
			errors.put("name","this field cannot be blank");
			
			
		}
		else if(keywordChecker(name)){
			errors.put("name","invalid entry in name field");
			
			
			
		}
		else if(charChecker(name)){
			errors.put("name","special charecters not allowed here");
			
			
			
		}
		else if(name.length()<=0){
			errors.put("name","this field cannot be blank");
			
			
		}
		else{
			

			request.setAttribute("cname",name);
			
			
		}
		
	for(String usedId:ids){
			if(usedId.equalsIgnoreCase(c_id)){
				errors.put("c_id","id already taken ");
				
			}
			else{
				request.setAttribute("cc_id",c_id);
				
			}
			
		}
	
	//email
	if(email==null)
	{
		errors.put("email","this field cannot be blank");
	}
	else{
		request.setAttribute("cemail",email);	
	}
		
		//address
		
		if(address==null){
			errors.put("address","this field cannot be blank");
			
			
		}
		else if(address.length()<=0){
			errors.put("address","this field cannot be blank");
			
			
		}
		else{
			request.setAttribute("caddress",address);	
		}
		
		//password
		if(password==null){
			errors.put("password","this field cannot be blank");
			
			
		}
		else if(password.length()<8){
			errors.put("password","password must be 8 chars");
			
			
		}
		else if(!password.equals(cpassword)){
			errors.put("password","password and confirm password are not same");
			
			
			
		}
		else{
			
			
			
		}
		
		if(errors.isEmpty()){
		
		RegisterModel rm=new RegisterModel();
		rm.setCid(c_id);
		rm.setName(name);
		rm.setAddress(address);
		rm.setPassword(password);
		rm.setEmail(email);
	ids.add(c_id);
		DbIntr di=FactoryClass.getInstance();
		
		try {
			if(di.insertToDb(rm)>0){
				request.setAttribute("message","Successfully registered");
							
			}
			else{
				request.setAttribute("message","registration failed");
							
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		}
		else{
			
			request.setAttribute("errors",errors);
			
			
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("customer_register.jsp");
		dispatcher.forward(request, response);
	}

}
