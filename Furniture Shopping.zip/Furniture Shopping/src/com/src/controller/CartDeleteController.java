package com.src.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.src.model.CartModel;

/**
 * Servlet implementation class CartDeleteController
 */
@WebServlet("/CartDeleteController")
public class CartDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartDeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fname=request.getParameter("delete_f");
		int a = 0;
		HttpSession session=request.getSession(false);
		String c_id=(String)session.getAttribute("cid");
		try{
		Context context = new InitialContext();
		DataSource lookup = (DataSource)context.lookup("java:/comp/env/jdbc/test");
		Connection con=lookup.getConnection();
		Statement stmt=con.createStatement();
		
		 a=stmt.executeUpdate("delete from cart where c_id='"+c_id+"' and fname='"+fname+"'");
											
		}catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(a>0)
		request.setAttribute("message","Success");
		else
			request.setAttribute("message","Deleteion failed");
		RequestDispatcher dispatcher = request.getRequestDispatcher("New.jsp");
		dispatcher.forward(request, response);
	}

}
