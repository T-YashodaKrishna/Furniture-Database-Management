package com.src.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.src.model.CustomerLoginModel;
import com.src.services.FactoryClass;

/**
 * Servlet implementation class CustomerLoginController
 */
@WebServlet("/CustomerLoginController")
public class CustomerLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerLoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String c_id=request.getParameter("c_id");
		String password=request.getParameter("password");
		
		CustomerLoginModel lm=new CustomerLoginModel();
		lm.setC_id(c_id);
		lm.setPassword(password);
		
	
		
		try {
			if(!FactoryClass.getInstance().checkDb(lm)){
				request.setAttribute("error","invalid id or password");
				request.getRequestDispatcher("customer_login.jsp").forward(request, response);
			}
			else{
				//System.out.println(c_id);
			HttpSession session=request.getSession();
			session.setAttribute("c_id",c_id);	
			request.getRequestDispatcher("customer_home_page.jsp").forward(request, response);
			
			
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
}

}
