package com.src.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.src.model.FurnitureAddModel;
import com.src.model.RegisterModel;
import com.src.services.DbIntr;
import com.src.services.FactoryClass;

/**
 * Servlet implementation class FurnitureAddController
 */
@WebServlet("/FurnitureAddController")
public class FurnitureAddController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FurnitureAddController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String addname=request.getParameter("add_name");
		String addprice=request.getParameter("add_cost");
		String addtype=request.getParameter("add_type");
		
		HashMap<String,String> errors=new HashMap<>();
		request.setAttribute("cname",addname);
		request.setAttribute("ctype",addtype);
		int price=0;
		try{
		price=Integer.parseInt(addprice);
		}
		catch(NumberFormatException ne){
			errors.put("price","price must be a valid integer");
		}
		//age
		if(price<0){
			errors.put("price","price cannot be negative");
		}
		if(errors.isEmpty()){
			
			FurnitureAddModel fam=new FurnitureAddModel();
			fam.setName(addname);
			fam.setPrice(price);
			fam.setType(addtype);
		
			DbIntr di=FactoryClass.getInstance();
			try {
				if(di.addtofurniture(fam)>0){
					request.setAttribute("message","Successfully Added");
								
				}
				else{
					request.setAttribute("message","Adding Failed");
								
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
		else{
			request.setAttribute("errors",errors);	
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("add_furniture.jsp");
		dispatcher.forward(request, response);

}
}
