package com.src.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.src.model.CartModel;

/**
 * Servlet implementation class BillController
 */
@WebServlet("/BillController")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			HttpSession session=request.getSession(false);
			String c_id=(String)session.getAttribute("cid");
			
			Context context = new InitialContext();
			DataSource lookup = (DataSource)context.lookup("java:/comp/env/jdbc/test");
			Connection con=lookup.getConnection();
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select fname,price from cart,furniture where c_id='"+c_id+"' and f_name=fname");
			int bill=0;
				List<CartModel> data=new ArrayList<>();
					while(rs.next()){
						CartModel p=new CartModel();
						p.setF_name(rs.getString("fname"));
						p.setPrice(rs.getInt("price"));
						bill+=rs.getInt("price");
						
					data.add(p);
					}
					ResultSet rs1=stmt.executeQuery("select c_id,c_name from customer where c_id='"+c_id+"'");
					
						List<CartModel> data1=new ArrayList<>();
							while(rs1.next()){
								CartModel q=new CartModel();
								q.setC_id(rs1.getString("c_id"));
								q.setC_name(rs1.getString("c_name"));
								data1.add(q);
							
							}
			request.setAttribute("CartList", data);
			request.setAttribute("CustomerList",data1);
			
			session.setAttribute("Total Bill",bill);
					
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("BillPrint.jsp").forward(request, response);
	}

}
