package com.src.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.src.services.DbIntr;
import com.src.services.FactoryClass;

/**
 * Servlet implementation class FurnitureUpdateController
 */
@WebServlet("/FurnitureUpdateController")
public class FurnitureUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FurnitureUpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		String updateprice=request.getParameter("update_cost");
		request.setAttribute("cname",name);
		HashMap<String,String> errors=new HashMap<>();
		int price=0;
		try{
		price=Integer.parseInt(updateprice);
		}
		catch(NumberFormatException ne){
			errors.put("price","price must be a valid integer");
		}
		//age
		if(price<0){
			errors.put("price","price cannot be negative");
		}
		if(errors.isEmpty()){
			DbIntr di=FactoryClass.getInstance();
			try {
				if(di.updatefurniture(name,price)>0){
					request.setAttribute("message","Successfully Updated");
								
				}
				else{
					request.setAttribute("message","Updating Failed");
								
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			request.setAttribute("errors",errors);
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("update_furniture.jsp");
		dispatcher.forward(request, response);
	}

}
