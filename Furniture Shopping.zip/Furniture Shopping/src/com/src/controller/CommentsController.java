package com.src.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.src.model.CommentsModel;
import com.src.services.FactoryClass;

/**
 * Servlet implementation class CommentsController
 */
@WebServlet("/CommentsController")
public class CommentsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CommentsController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);
		String c_id = (String)session.getAttribute("cid");
		
		String about=request.getParameter("about");
		String comments=request.getParameter("comments");
		String ratingex=request.getParameter("rating");
		HashMap<String,String> errors=new HashMap<>();
		int rating=0;
		try{
			rating=Integer.parseInt(ratingex);
			}
			catch(NumberFormatException ne){
				errors.put("rating","rating must be a valid integer");
			}
			//age
			if((rating<0)||(rating>10)){
				errors.put("rating","rating must be between 0 and 10");			
			}
			else{
				
				request.setAttribute("crating",rating);
				
			}
		
		if(about==null){
			errors.put("about","about field cannot be blank");
		}
		else{		
			request.setAttribute("cabout",about);					
		}
		if(comments==null){
			errors.put("comments","about field cannot be blank");
		}
		else{		
			request.setAttribute("ccomments",comments);					
		}
		if(errors.isEmpty()){
		CommentsModel cm =new CommentsModel();
		cm.setC_id(c_id);
		cm.setAbout(about);
		cm.setComments(comments);
		cm.setRating(rating);
		
		try {
			if(FactoryClass.getInstance().addComments(cm))
			{
			request.setAttribute("comment_result","COMMENT STORED SUCCESSFULLY.");
			
			}
			else
			{
				request.setAttribute("comment_result","COMMENT NOT STORED!!");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		else{
			request.setAttribute("errors",errors);		
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("customer_home_page.jsp");
		dispatcher.forward(request, response);
	}

}
